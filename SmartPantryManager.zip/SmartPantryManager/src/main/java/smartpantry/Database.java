package smartpantry;

import java.sql.*;
import java.time.LocalDate;
import java.util.*;

public class Database {
    private static final String URL = "jdbc:sqlite:smartpantry.db";
    private Connection connect() throws SQLException { return DriverManager.getConnection(URL); }

    public void initialize() {
        try (Connection c = connect(); Statement s = c.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS pantry_items(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, expiry TEXT)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS recipes(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, method TEXT NOT NULL)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS recipe_ingredients(id INTEGER PRIMARY KEY AUTOINCREMENT, recipe_id INTEGER NOT NULL, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL, FOREIGN KEY(recipe_id) REFERENCES recipes(id))");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)");
            s.execute("PRAGMA foreign_keys = ON");
            seed(c);
        } catch (SQLException e) { throw new RuntimeException("Could not initialize database", e); }
    }

    private void seed(Connection c) throws SQLException {
        try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT COUNT(*) FROM recipes")) { if (rs.next() && rs.getInt(1) > 0) return; }
        String[][] data = {
          {"Tomato pasta","Boil pasta. Simmer chopped tomato with oil and salt, then combine.","pasta|100|g;tomato|100|g;olive oil|5|ml; salt|1|g"},
          {"Cheese omelette","Beat eggs, cook in a pan, add cheese, fold and serve.","egg|2|pcs;cheese|30|g"},
          {"Banana pancakes","Mash banana, mix with egg and flour, then cook small pancakes.","banana|1|pcs;egg|1|pcs;flour|50|g"},
          {"Garlic rice","Cook rice. Warm oil and garlic, stir through the rice.","rice|100|g;garlic|5|g;olive oil|5|ml"},
          {"Simple salad","Chop and toss all vegetables with oil and salt.","tomato|100|g;cucumber|100|g;lettuce|50|g;olive oil|5|ml"},
          {"Grilled cheese sandwich","Place cheese between bread slices and toast until golden.","bread|2|slices;cheese|40|g"},
          {"Egg fried rice","Scramble egg, add cooked rice and peas, stir-fry.","rice|150|g;egg|1|pcs;peas|30|g;olive oil|5|ml"},
          {"Tomato soup","Cook tomato with onion and water, then blend.","tomato|200|g;onion|50|g;water|200|ml"},
          {"Apple banana bowl","Slice fruit and serve together.","apple|1|pcs;banana|1|pcs"},
          {"Peanut butter toast","Spread peanut butter on bread.","bread|2|slices;peanut butter|20|g"},
          {"Garlic pasta","Boil pasta and toss with warmed garlic and oil.","pasta|100|g;garlic|5|g;olive oil|10|ml"},
          {"Cheese tomato toast","Top bread with tomato and cheese; toast until melted.","bread|2|slices;tomato|50|g;cheese|30|g"},
          {"Potato mash","Boil potatoes until soft and mash with milk and butter.","potato|200|g;milk|30|ml;butter|10|g"},
          {"Carrot salad","Grate carrot and apple, toss and serve.","carrot|100|g;apple|1|pcs"},
          {"Banana smoothie","Blend banana with milk.","banana|1|pcs;milk|200|ml"},
          {"Onion omelette","Cook sliced onion, add beaten eggs and cook through.","egg|2|pcs;onion|30|g"},
          {"Pea rice","Cook rice, stir in peas and a little oil.","rice|100|g;peas|50|g;olive oil|5|ml"},
          {"Tomato cucumber salad","Chop tomato and cucumber and mix with salt.","tomato|100|g;cucumber|100|g"},
          {"Buttered bread","Spread butter on bread and serve.","bread|2|slices;butter|10|g"},
          {"Apple oatmeal","Cook oats with milk and top with chopped apple.","oats|50|g;milk|200|ml;apple|1|pcs"}
        };
        try (PreparedStatement rp = c.prepareStatement("INSERT INTO recipes(name,method) VALUES(?,?)", Statement.RETURN_GENERATED_KEYS);
             PreparedStatement ip = c.prepareStatement("INSERT INTO recipe_ingredients(recipe_id,name,quantity,unit) VALUES(?,?,?,?)")) {
            for (String[] d : data) {
                rp.setString(1,d[0]); rp.setString(2,d[1]); rp.executeUpdate();
                int id;
                try (ResultSet keys = rp.getGeneratedKeys()) { if (keys.next()) id = keys.getInt(1); else try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery("SELECT id FROM recipes WHERE name='"+d[0].replace("'","''")+"'")) { rs.next(); id=rs.getInt(1); } }
                for (String part : d[3].split(";")) {
                    String[] a = part.trim().split("\\|");
                    ip.setInt(1,id); ip.setString(2,a[0].trim().toLowerCase(Locale.ROOT)); ip.setDouble(3,Double.parseDouble(a[1])); ip.setString(4,a[2].trim().toLowerCase(Locale.ROOT)); ip.executeUpdate();
                }
            }
        }
    }

    public List<PantryItem> getPantry() {
        List<PantryItem> out = new ArrayList<>();
        try (Connection c=connect(); Statement s=c.createStatement(); ResultSet r=s.executeQuery("SELECT * FROM pantry_items ORDER BY name")) {
            while(r.next()) out.add(new PantryItem(r.getInt("id"),r.getString("name"),r.getDouble("quantity"),r.getString("unit"),Objects.toString(r.getString("expiry"),"")));
        } catch(SQLException e){ throw new RuntimeException(e); } return out;
    }
    public void addPantry(PantryItem i) { executePantry("INSERT INTO pantry_items(name,quantity,unit,expiry) VALUES(?,?,?,?)",i); }
    public void updatePantry(PantryItem i) { executePantry("UPDATE pantry_items SET name=?,quantity=?,unit=?,expiry=? WHERE id=?",i); }
    private void executePantry(String sql, PantryItem i) {
        try(Connection c=connect(); PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,i.name.toLowerCase(Locale.ROOT)); p.setDouble(2,i.quantity); p.setString(3,i.unit.toLowerCase(Locale.ROOT)); p.setString(4,i.expiry.isBlank()?null:i.expiry);
            if(sql.startsWith("UPDATE")) p.setInt(5,i.id); p.executeUpdate();
        }catch(SQLException e){throw new RuntimeException(e);}
    }
    public void deletePantry(int id){try(Connection c=connect();PreparedStatement p=c.prepareStatement("DELETE FROM pantry_items WHERE id=?")){p.setInt(1,id);p.executeUpdate();}catch(SQLException e){throw new RuntimeException(e);}}

    public List<Recipe> getRecipes() {
        List<Recipe> out=new ArrayList<>();
        try(Connection c=connect();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT * FROM recipes ORDER BY name")){
            while(r.next()) out.add(loadRecipe(c,r.getInt("id"),r.getString("name"),r.getString("method")));
        }catch(SQLException e){throw new RuntimeException(e);} return out;
    }
    private Recipe loadRecipe(Connection c,int id,String name,String method)throws SQLException{
        List<RecipeIngredient> ingredients=new ArrayList<>();
        try(PreparedStatement p=c.prepareStatement("SELECT name,quantity,unit FROM recipe_ingredients WHERE recipe_id=? ORDER BY id")){p.setInt(1,id);try(ResultSet r=p.executeQuery()){while(r.next())ingredients.add(new RecipeIngredient(r.getString(1),r.getDouble(2),r.getString(3)));}}
        return new Recipe(id,name,method,ingredients);
    }
    public List<Recipe> suggestedRecipes() {
        Map<String,Double> available=new HashMap<>();
        for(PantryItem p:getPantry()) {
            String key=p.name.trim().toLowerCase(Locale.ROOT)+"|"+p.unit.trim().toLowerCase(Locale.ROOT);
            available.merge(key,p.quantity,Double::sum);
        }
        List<Recipe> matches=new ArrayList<>();
        for(Recipe r:getRecipes()){
            boolean ok=true;
            for(RecipeIngredient i:r.ingredients){
                String key=i.name.trim().toLowerCase(Locale.ROOT)+"|"+i.unit.trim().toLowerCase(Locale.ROOT);
                if(available.getOrDefault(key,0.0)+1e-9 < i.quantity){ok=false;break;}
            }
            if(ok)matches.add(r);
        }
        return matches;
    }
    public String getSetting(String key,String fallback){try(Connection c=connect();PreparedStatement p=c.prepareStatement("SELECT value FROM settings WHERE key=?")){p.setString(1,key);try(ResultSet r=p.executeQuery()){return r.next()?r.getString(1):fallback;}}catch(SQLException e){return fallback;}}
    public void setSetting(String key,String value){try(Connection c=connect();PreparedStatement p=c.prepareStatement("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")){p.setString(1,key);p.setString(2,value);p.executeUpdate();}catch(SQLException e){throw new RuntimeException(e);}}
    public List<String> expiringSoon(){
        List<String> out=new ArrayList<>(); LocalDate now=LocalDate.now(), end=now.plusDays(7);
        for(PantryItem i:getPantry()) if(!i.expiry.isBlank()) try{LocalDate d=LocalDate.parse(i.expiry);if(!d.isBefore(now)&&!d.isAfter(end))out.add(i.name+" — "+i.expiry);}catch(Exception ignored){}
        return out;
    }
}
