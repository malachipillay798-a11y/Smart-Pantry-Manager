package smartpantry;

public class PantryItem {
    public final int id;
    public final String name;
    public final double quantity;
    public final String unit;
    public final String expiry;
    public PantryItem(int id, String name, double quantity, String unit, String expiry) {
        this.id = id; this.name = name; this.quantity = quantity; this.unit = unit; this.expiry = expiry == null ? "" : expiry;
    }
}
