package smartpantry;

public class RecipeIngredient {
    public final String name, unit;
    public final double quantity;
    public RecipeIngredient(String name, double quantity, String unit) { this.name = name; this.quantity = quantity; this.unit = unit; }
}
