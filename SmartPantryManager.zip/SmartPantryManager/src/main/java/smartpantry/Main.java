package smartpantry;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class Main extends JFrame {
    private final Database db = new Database();
    private final DefaultListModel<String> pantryModel = new DefaultListModel<>();
    private final JList<String> pantryList = new JList<>(pantryModel);
    private final DefaultListModel<String> recipeModel = new DefaultListModel<>();
    private final JList<String> recipeList = new JList<>(recipeModel);
    private final JTextArea details = new JTextArea();
    private List<PantryItem> pantry = List.of();
    private List<Recipe> recipes = List.of();

    public Main() {
        super("Smart Pantry Manager");
        db.initialize();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Pantry", pantryPanel());
        tabs.addTab("Suggested Recipes", suggestedPanel());
        tabs.addTab("All Recipes", recipesPanel());
        tabs.addTab("Settings", settingsPanel());
        add(tabs, BorderLayout.CENTER);
        refreshPantry();
        refreshRecipes();
    }

    private JPanel pantryPanel() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        pantryList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        p.add(new JScrollPane(pantryList), BorderLayout.CENTER);
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton add = new JButton("Add item");
        JButton edit = new JButton("Edit selected");
        JButton delete = new JButton("Delete selected");
        add.addActionListener(e -> itemDialog(null));
        edit.addActionListener(e -> { PantryItem item = selectedPantry(); if (item != null) itemDialog(item); });
        delete.addActionListener(e -> {
            PantryItem item = selectedPantry();
            if (item != null && JOptionPane.showConfirmDialog(this, "Delete " + item.name + "?", "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                db.deletePantry(item.id); refreshPantry();
            }
        });
        buttons.add(add); buttons.add(edit); buttons.add(delete);
        p.add(buttons, BorderLayout.SOUTH);
        return p;
    }

    private JPanel suggestedPanel() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        JList<String> list = new JList<>(new DefaultListModel<>());
        JTextArea info = new JTextArea("Only recipes for which every required ingredient and quantity is available are shown.");
        info.setEditable(false); info.setLineWrap(true); info.setWrapStyleWord(true);
        JButton refresh = new JButton("Find recipes I can make");
        refresh.addActionListener(e -> {
            refreshPantry();
            DefaultListModel<String> model = (DefaultListModel<String>) list.getModel();
            model.clear();
            List<Recipe> matches = db.suggestedRecipes();
            for (Recipe r : matches) model.addElement(r.name);
            if (matches.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No recipes match your pantry yet - add more ingredients.", "No matches", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        list.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && list.getSelectedIndex() >= 0) {
                List<Recipe> matches = db.suggestedRecipes();
                if (list.getSelectedIndex() < matches.size()) showRecipe(matches.get(list.getSelectedIndex()));
            }
        });
        p.add(info, BorderLayout.NORTH);
        p.add(new JScrollPane(list), BorderLayout.CENTER);
        p.add(refresh, BorderLayout.SOUTH);
        return p;
    }

    private JPanel recipesPanel() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        recipeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        details.setEditable(false); details.setLineWrap(true); details.setWrapStyleWord(true);
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(recipeList), new JScrollPane(details));
        split.setDividerLocation(280);
        recipeList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && recipeList.getSelectedIndex() >= 0 && recipeList.getSelectedIndex() < recipes.size()) showRecipe(recipes.get(recipeList.getSelectedIndex()));
        });
        p.add(split, BorderLayout.CENTER);
        return p;
    }

    private JPanel settingsPanel() {
        JPanel p = new JPanel(new GridLayout(0, 1, 8, 8));
        JCheckBox alerts = new JCheckBox("Show expiring-soon alerts", db.getSetting("expiry_alerts", "true").equals("true"));
        alerts.addActionListener(e -> db.setSetting("expiry_alerts", Boolean.toString(alerts.isSelected())));
        JLabel label = new JLabel("Smart Pantry Manager — local SQLite storage. Dates use YYYY-MM-DD.");
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        p.add(label); p.add(alerts);
        JButton check = new JButton("Check items expiring within 7 days");
        check.addActionListener(e -> {
            List<String> expiring = db.expiringSoon();
            JOptionPane.showMessageDialog(this, expiring.isEmpty() ? "No items expiring within the next 7 days." : String.join("\n", expiring), "Expiry report", JOptionPane.INFORMATION_MESSAGE);
        });
        p.add(check);
        return p;
    }

    private void itemDialog(PantryItem old) {
        JTextField name = new JTextField(old == null ? "" : old.name);
        JTextField qty = new JTextField(old == null ? "1" : Double.toString(old.quantity));
        JTextField unit = new JTextField(old == null ? "pcs" : old.unit);
        JTextField expiry = new JTextField(old == null ? "" : old.expiry);
        JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
        form.add(new JLabel("Ingredient name")); form.add(name);
        form.add(new JLabel("Quantity")); form.add(qty);
        form.add(new JLabel("Unit (g, ml, pcs, etc.)")); form.add(unit);
        form.add(new JLabel("Expiry date (YYYY-MM-DD, optional)")); form.add(expiry);
        if (JOptionPane.showConfirmDialog(this, form, old == null ? "Add pantry item" : "Edit pantry item", JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        try {
            String n = name.getText().trim(), u = unit.getText().trim(), ex = expiry.getText().trim();
            double q = Double.parseDouble(qty.getText().trim());
            if (n.isEmpty() || u.isEmpty() || q < 0) throw new IllegalArgumentException("Enter a name, unit, and non-negative quantity.");
            if (!ex.isEmpty()) LocalDate.parse(ex);
            PantryItem item = new PantryItem(old == null ? 0 : old.id, n, q, u, ex);
            if (old == null) db.addPantry(item); else db.updatePantry(item);
            refreshPantry();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid input. Quantity must be numeric and expiry date must use YYYY-MM-DD.\n" + ex.getMessage(), "Input error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private PantryItem selectedPantry() {
        int index = pantryList.getSelectedIndex();
        if (index < 0 || index >= pantry.size()) { JOptionPane.showMessageDialog(this, "Select a pantry item first."); return null; }
        return pantry.get(index);
    }
    private void refreshPantry() {
        pantry = db.getPantry(); pantryModel.clear();
        for (PantryItem i : pantry) pantryModel.addElement(i.name + " — " + i.quantity + " " + i.unit + (i.expiry.isBlank() ? "" : " (expires " + i.expiry + ")"));
    }
    private void refreshRecipes() {
        recipes = db.getRecipes(); recipeModel.clear();
        for (Recipe r : recipes) recipeModel.addElement(r.name);
    }
    private void showRecipe(Recipe r) {
        StringBuilder b = new StringBuilder(r.name).append("\n\nIngredients:\n");
        for (RecipeIngredient i : r.ingredients) b.append("• ").append(i.name).append(": ").append(i.quantity).append(" ").append(i.unit).append("\n");
        b.append("\nMethod:\n").append(r.method);
        details.setText(b.toString()); details.setCaretPosition(0);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}
