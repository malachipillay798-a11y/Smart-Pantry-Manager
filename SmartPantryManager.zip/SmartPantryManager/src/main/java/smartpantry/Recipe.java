package smartpantry;

import java.util.List;

public class Recipe {
    public final int id;
    public final String name, method;
    public final List<RecipeIngredient> ingredients;
    public Recipe(int id, String name, String method, List<RecipeIngredient> ingredients) {
        this.id = id; this.name = name; this.method = method; this.ingredients = ingredients;
    }
}
