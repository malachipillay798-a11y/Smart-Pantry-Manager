# Smart Pantry Manager (IntelliJ IDEA / Java)

## Run
1. Open IntelliJ IDEA and choose **Open**.
2. Select the `SmartPantryManager` folder (the folder containing `pom.xml`).
3. Use JDK 17 or newer and allow IntelliJ to load the Maven project.
4. Open `src/main/java/smartpantry/Main.java` and click Run.

SQLite database `smartpantry.db` is created in the project working directory automatically. The app seeds 20 recipes on first launch.

Pantry quantities are compared only when units match (case-insensitive); recipe ingredients are strict: every ingredient and required quantity must be available. Enter dates as `YYYY-MM-DD` or leave blank.
